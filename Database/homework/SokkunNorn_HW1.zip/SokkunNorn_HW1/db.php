
<?php

header('Content-Type: Application/json');
header('Access-Control-Allow-Origin: *');
sleep(1);

$conn = mysqli_connect('localhost', 'root', '' , 'test');

if(!$conn) {
    echo 'game over';
}

if(isset($_POST['name'])){

    $value = $_POST['name'];

    $request = "call selectStudent('" + $value + "')";
    // Execute the insert query
    $result = mysqli_query($conn, $request);

    // if the result is 0, display error message
    if ($result == FALSE) {
        echo json_encode(array('message' => "error: " . mysqli_error($con)));
    }	
    else {
        echo json_encode(array('message' => 'ok'));
    }

} else {

    $query = "select * from view_info_student";
    $select = mysqli_query($conn, $query);

    $data = array();

    while($row = mysqli_fetch_assoc($select)) {
        $data[] = $row;
    }

    echo(json_encode($data));

}


