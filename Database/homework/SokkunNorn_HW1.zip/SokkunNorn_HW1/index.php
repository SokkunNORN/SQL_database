
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Select Student</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="jquery.js"></script>
</head>
<body id="body">
    <div class="container mt-5">
        <h2>Ajax Search with Store Procedure</h2>
        <form action="#!" method="post">
            <div class="input-group mb-3">
                <input type="text" class="form-control" id="student" name="name"  
                    onchange="search(this.value)" placeholder="Search Student List">
                <div class="input-group-append">
                    <span class="input-group-text bg-primary text-white">Search</span>
                </div>
            </div>
        </form>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>University</th>
                    <th>GPA</th>
                </tr>
            </thead>
            <tbody id="tbody">
               <tr>
                   <td></td>
                   <td></td>
                   <td class="text-center">data loading...</td>
                   <td></td>
                   <td></td>
               </tr>
            </tbody>
        </table>
    </div>

    <script src="script.js"></script>
</body>
</html>




