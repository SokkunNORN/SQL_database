
var url = "http://localhost/database/homework/SokkunNorn_HW1/db.php";

function getStudent() {
    $.ajax({
        url: url,
        dataType: 'json'
    })
    .done(displayData)
    .fail(error);
}

function displayData(json) {
    var output;
    var i;
    for (i = 0; i < json.length; i++) {
        output += "<tr><td>" + json[i].studentid + "</td><td>" + json[i].fullName + "</td><td>"
               + json[i].email + "</td><td>" + json[i].university + "</td><td>" + json[i].GPA + "</td></tr>";
    }
    $('#tbody').html(output);
}

function error(error){
    $("#body").removeClass('loading');
    $("#error").html('Sorry, there was an error: ' + error.statusText + " (" + error.status + ")")
    .css('color','red');
}

$(document).ready(function() {
    getStudent();
});

function search(value) {
    if (value=="") {
      document.getElementById("txtHint").innerHTML="";
      return;
    } 
    if (window.XMLHttpRequest) {
      // code for IE7+, Firefox, Chrome, Opera, Safari
      xmlhttp=new XMLHttpRequest();
    } else { // code for IE6, IE5
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function() {
      if (this.readyState==4 && this.status==200) {
        document.getElementById("txtHint").innerHTML=this.responseText;
      }
    }
    xmlhttp.open("POST","db.php?q="+value,true);
    xmlhttp.send();
  }


